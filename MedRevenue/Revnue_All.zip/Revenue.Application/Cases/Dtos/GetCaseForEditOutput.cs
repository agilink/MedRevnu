namespace ATI.Revenue.Application.Cases.Dtos
{
    public class GetCaseForEditOutput
    {
        public CreateOrEditCaseDto Case { get; set; }
    }
}