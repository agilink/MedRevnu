namespace ATI.Revenue.Application.Cases.Dtos
{
    public class GetCaseForViewDto
    {
        public CaseDto Case { get; set; }
    }
}